import React, { useState } from "react";
import Modal from "../../../../Modals/Modal";
import s from "./ProductRegister.module.css"
import arrow from "../../../../../img/tickPhone.png"

const ProductRegister = ({close}) =>{
    const [control, setControl] = useState({
        selectPrice: false,
        selectCategories: false,
        showDefPrice: false,
        showVarietPrice: false,
        changeArrowCategory: false,
        changeArrowType: false,
        langGeName: true,
        langEnName: false,
        langeRuName: false,
        langGeDisc: true,
        langEnDisc: false,
        langeRuDisc: false,
        langGeChar: true,
        langEnChar: false,
        langeRuChar: false,
        lang: 'ge'
    })
    const [state, setState] = useState({
        title:{
            en: "",
            ge: "",
            ru: ""
        },
        discription:{
            en: "",
            ge: "",
            ru: ""
        },
        category: "",
        characteritics:{
            en: "",
            ge: "",
            ru: ""
        },
        type:{
            variable: false,
            defaulte: false
        },
        productImg:{
            main: {
                alt: "",
                title: "",
                src: ""
            },
            pics : []
        }
    })
    const sendForm = (event) =>{
        console.log(state)
        event.preventDefault()
    }

    return(
        <Modal>
            <div className={s.wrap} onClick={(e)=>e.target.className === s.wrap ? close() : null}>
                <form action="" onSubmit={sendForm} className={s.form}>
                    <div className={s.form__in}>
                        <div className={s.input__div}>
                            <h2>Добавить товар</h2>
                        </div>
                        <div className={s.input__div}>
                            <label className={s.input__label} htmlFor="">
                                <p>Название</p> 
                                <div className={s.langs}>
                                    <span className={`${s.input__lang} ${control.langGeName ? s.input__lang__spec : null}`} onClick={()=>{setControl({...control, lang: 'ge', langGeName: true, langEnName: false, langeRuName: false})}}>Ge</span>
                                    <span className={`${s.input__lang} ${control.langEnName ? s.input__lang__spec : null}`} onClick={()=>{setControl({...control, lang: 'en', langGeName: false, langEnName: true, langeRuName: false})}}>En</span>
                                    <span className={`${s.input__lang} ${control.langeRuName ? s.input__lang__spec : null}`} onClick={()=>{setControl({...control, lang: 'ru', langGeName: false, langEnName: false, langeRuName: true})}}>Ru</span>
                                </div>
                            </label>
                            <input value={state.title[control.lang]} required className={s.input} type="text" onChange={(event)=>{
                               setState({...state, title: {...state.title, [control.lang]: event.target.value}})
                            }}/>
                        </div>
                        <div className={s.input__div}>
                            <label className={s.input__label} htmlFor="">
                                <p>Категория</p>
                            </label>
                            <div className={s.select}>
                                <div className={s.select__in} onClick={()=>{setControl({...control, selectCategories: !control.selectCategories, changeArrowCategory: !control.changeArrowCategory})}}>
                                    <input type="text" required disabled className={s.input__select} value={state.category}/>
                                    <img src={arrow} className={`${s.arrow} ${control.changeArrowCategory ? s.arrow__deg : null}`} alt="Стрелка"/>
                                </div>
                                {control.selectCategories ? <div className={s.select__input__wrap}>
                                    <p className={s.select__p} onClick={()=>{
                                        setState({...state, category: "Футбол"})
                                        setControl({...control, selectCategories: !control.selectCategories})
                                    }}>Футбол</p>
                                    <p className={s.select__p} onClick={()=>{
                                        setState({...state, category: "Дом и уют"}) 
                                        setControl({...control, selectCategories: !control.selectCategories})
                                    }}>Дом и уют</p>
                                </div> : null}
                            </div>
                        </div>
                        <div className={s.input__div}>
                            <label className={s.input__label} htmlFor="">
                                <p>Тип</p>
                            </label>
                            <div className={s.select}>
                                <div className={s.select__in} onClick={()=>{setControl({...control, selectPrice: !control.selectPrice, changeArrowType: !control.changeArrowType})}}>
                                    <input type="text" required disabled className={s.input__select} value={state.type.variable ? "Вариативный" : "Не вариативный"}/>
                                    <img src={arrow} className={`${s.arrow} ${control.changeArrowType ? s.arrow__deg : null}`} alt="Стрелка"/>
                                </div>
                                {control.selectPrice ? <div className={s.select__input__wrap}>
                                    <p className={s.select__p} onClick={()=>{
                                        setState({...state, type: {...state.type, variable: true, defaulte: false}})
                                        setControl({...control, selectPrice: !control.selectPrice})
                                    }}>Вариативный</p>
                                    <p className={s.select__p} onClick={()=>{
                                       setState({...state, type: {...state.type, variable: false, defaulte: true}})  
                                       setControl({...control, selectPrice: !control.selectPrice})  
                                    }}>Не вариативный</p>
                                </div> : null}
                            </div>
                        </div>
                        <div className={s.input__div}>
                            <label className={s.input__label} htmlFor="">
                                <p>Цена</p>
                            </label>
                            <div className={s.input__price__wrap}>
                                <div className={s.add__price} onClick={()=>{
                                    
                                }}>
                                    <span className={`${s.span} ${s.span1}`}></span>
                                    <span className={`${s.span} ${s.span2}`}></span>
                                </div>
                            </div>
                        </div>
                        <div className={s.input__div}>
                            <label htmlFor="" className={s.input__label}>
                                <p>Описание</p>
                                <div className={s.langs}>
                                    <span className={`${s.input__lang} ${control.langGeDisc ? s.input__lang__spec : null}`} onClick={()=>{setControl({...control, lang: 'ge', langGeDisc: true, langEnDisc: false, langeRuDisc: false})}}>Ge</span>
                                    <span className={`${s.input__lang} ${control.langEnDisc ? s.input__lang__spec : null}`} onClick={()=>{setControl({...control, lang: 'en', langGeDisc: false, langEnDisc: true, langeRuDisc: false})}}>En</span>
                                    <span className={`${s.input__lang} ${control.langeRuDisc ? s.input__lang__spec : null}`} onClick={()=>{setControl({...control, lang: 'ru', langGeDisc: false, langEnDisc: false, langeRuDisc: true})}}>Ru</span>
                                </div>
                            </label>
                            <textarea required value={state.discription[control.lang]} className={s.textarea} name="" id="" cols="30" rows="10" onChange={(event)=>{
                                setState({...state, discription: {...state.discription, [control.lang]: event.target.value}})
                            }}></textarea>
                        </div>
                        <div className={s.input__div}>
                            <label htmlFor="" className={s.input__label}>
                                <p>Характеристики</p>
                                <div className={s.langs}>
                                    <span className={`${s.input__lang} ${control.langGeChar ? s.input__lang__spec : null}`} onClick={()=>{setControl({...control, lang: 'ge', langGeChar: true, langEnChar: false, langeRuChar: false})}}>Ge</span>
                                    <span className={`${s.input__lang} ${control.langEnChar ? s.input__lang__spec : null}`} onClick={()=>{setControl({...control, lang: 'en', langGeChar: false, langEnChar: true, langeRuChar: false})}}>En</span>
                                    <span className={`${s.input__lang} ${control.langeRuChar ? s.input__lang__spec : null}`} onClick={()=>{setControl({...control, lang: 'ru', langGeChar: false, langEnChar: false, langeRuChar: true})}}>Ru</span>
                                </div>
                            </label>
                            <textarea required value={state.characteritics[control.lang]} className={s.textarea} name="" id="" cols="30" rows="10" onChange={(event)=>{
                                setState({...state, characteritics: {...state.characteritics, [control.lang]: event.target.value}})
                            }}></textarea>
                        </div>
                        <div className={s.input__div}>
                            <label htmlFor="" className={s.input__label}>
                                <p>Главное изображение</p>
                            </label>
                            
                        </div>
                        <div className={s.input__div}>
                            <label htmlFor="" className={s.input__label}>
                                <p>Дополнительные изображения</p>
                            </label>
                            
                        </div>
                    </div>
                    <div className={s.btn__wrap}>
                        <button className={`${s.form__btn} ${s.form__btn__save}`}>Сохранить как черновик</button>
                        <button className={`${s.form__btn} ${s.form__btn__send}`}>Отправить</button>
                    </div>
                </form>
            </div>
        </Modal>
    )
}
export default ProductRegister;