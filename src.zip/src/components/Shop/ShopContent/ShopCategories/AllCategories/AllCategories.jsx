import React, { useEffect, useState } from "react";
import CatCreateTreeHTML from "./CategoriesCreateTree/CatCreateTreeHTML";
import { api } from "../../../../functions/api";


const createTreeData = (arr, idProp, parentProp) => {
    const tree = Object.fromEntries(arr.map(n => [ n[idProp], { ...n, children: [] } ]));
    return Object.values(tree).filter(n => !tree[n[parentProp]]?.children.push(n));
  };


const AllCategories = ({shop})=>{
    const [cats,setCats] = useState([]);
    useEffect(()=>{
        api((arg)=>{
            setCats(createTreeData(arg,'id','parent_id'));
        },{},"manage/categories/get-categories.php")
    },[])
    function addCategory(data){
        console.log(shop.id)
        //return
        api((arg)=>{
            alert(arg)
        },{shopID:shop.id,catID:data.catID},"manage/categories/add-favorite.php")
    }
    return(
        <div>
            <div>
                <h3>Все категории</h3>
                <CatCreateTreeHTML data={cats} addCategory = {(arg)=>{addCategory(arg)}}/>
            </div>
            <div>
                <h3>Категории в избранном</h3>

            </div>
        </div>
    )
}

export default AllCategories;