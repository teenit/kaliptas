import React from "react";
const FrontDescriptionFeedbacks =()=>{
    return(
        <h2><b>Отзывы о</b><span style={{ color: '#cbced4', fontWeight: '100' }}> product name</span></h2>
    )
}
export default FrontDescriptionFeedbacks;