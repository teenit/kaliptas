import React from "react";
const FrontDescriptionQuestions =()=>{
    return(
        <h2><b>Вопросы о</b><span style={{ color: '#cbced4', fontWeight: '100' }}> product name</span></h2>
    )
}
export default FrontDescriptionQuestions;