import React from "react";
const FrontDescriptionInfo =()=>{
    return(
        <div>
        <h2><b>Описание</b><span style={{ color: '#cbced4', fontWeight: '100' }}> product name</span></h2>
        <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit.
            Temporibus sed adipisci delectus libero optio, sunt tenetur quae dolorum at incidunt a quibusdam impedit.
            In amet accusamus aliquid, repellat corporis quisquam. Lorem ipsum dolor sit amet,
            consectetur adipisicing elit. Dolore, quis porro tempora aliquam quibusdam iusto?
            Velit esse perspiciatis iste dolorum neque sed dicta,
            error exercitationem mollitia minima asperiores illum. Nesciunt.
            Lorem ipsum dolor sit amet consectetur, adipisicing elit.
            Dignissimos sint recusandae soluta dolorem maxime rem ipsam?
            Rem nesciunt unde perspiciatis fugiat illo error animi at sed deserunt nisi. Nihil, tempore!</p>
    </div>
    )
}
export default FrontDescriptionInfo;