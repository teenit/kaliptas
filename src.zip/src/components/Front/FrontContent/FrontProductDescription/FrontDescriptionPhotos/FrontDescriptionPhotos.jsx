import React from "react";
const FrontDescriptionPhotos =()=>{
    return(
        <h2><b>Фотографии</b><span style={{ color: '#cbced4', fontWeight: '100' }}> product name</span></h2>
    )
}
export default FrontDescriptionPhotos;