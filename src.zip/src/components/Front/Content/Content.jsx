import React from "react";
import s from './Content.module.css'
import { useState } from "react";
import FloatButton from "./FloatButton/FloatButton";
import Banner from "./Banner/Banner";
import Item from "./Item/Item";
import Offers from "./Offers/Offers";
import ItemDesc from "./ItemDesc/ItemDesc";
const Content = () => {

    return (
        <div className={s.wrapper}>
            <FloatButton />
            <div className={s.inner}>
                <Item />
                <ItemDesc />
                <Offers />
                <Banner />
            </div>
        </div>
    )
}
export default Content;
