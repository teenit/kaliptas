import React from "react";
const DescChar =()=>{
    return(
        <div>DescChar</div>
    )
}
export default DescChar;