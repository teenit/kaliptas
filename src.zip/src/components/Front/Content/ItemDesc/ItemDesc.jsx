import React, { useState } from "react";
import s from './ItemDesc.module.css'
import DescMini from "./DescMini/DescMini";
import DescInfo from "./DescInfo/DescInfo";
import DescChar from "./DescChar/DescChar";
import DescQuestions from "./DescQuestions/DescQuestions";
import DescPhotos from "./DescPhotos/DescPhotos";
import DescFeedbacks from "./DescFeedbacks/DescFeedbacks";
const ItemDesc = () => {
    const [desc, setDesc] = useState(true)
    const [char, setChar] = useState(false)
    const [questions, setQuestions] = useState(false)
    const [feedbacks, setFeedbacks] = useState(false)
    const [photos, setPhotos] = useState(false)
    return (
        <div className={s.desc}>
            <div className={s.desc__info}>

                <nav className={s.desc__menu}>
                    <p tabIndex={0} onClick={() => {
                        setDesc(true)
                        setChar(false)
                        setQuestions(false)
                        setFeedbacks(false)
                        setPhotos(false)
                    }}><b>Описание</b></p>
                    <div className={s.desc__menu__line}></div>
                    <p tabIndex={0} onClick={() => {
                        setDesc(false)
                        setChar(true)
                        setQuestions(false)
                        setFeedbacks(false)
                        setPhotos(false)
                    }}><b>Характеристики</b></p>
                    <div className={s.desc__menu__line}></div>
                    <p tabIndex={0} onClick={() => {
                        setDesc(false)
                        setChar(false)
                        setQuestions(true)
                        setFeedbacks(false)
                        setPhotos(false)
                    }}><b>Вопросы</b></p>
                    <div className={s.desc__menu__line}></div>
                    <p tabIndex={0} onClick={() => {
                        setDesc(false)
                        setChar(false)
                        setQuestions(false)
                        setFeedbacks(true)
                        setPhotos(false)
                    }}><b>Отзывы</b></p>
                    <div className={s.desc__menu__line}></div>
                    <p tabIndex={0} onClick={() => {
                        setDesc(false)
                        setChar(false)
                        setQuestions(false)
                        setFeedbacks(false)
                        setPhotos(true)
                    }}><b>Фото</b></p>
                </nav>


                {desc ? <DescInfo /> : null}
                {char ? <DescChar />: null}
                {questions ? <DescQuestions />:null}
                {feedbacks ? <DescFeedbacks />:null}
                {photos ? <DescPhotos />:null}

            </div>
            <DescMini />
        </div>
    )
}
export default ItemDesc;