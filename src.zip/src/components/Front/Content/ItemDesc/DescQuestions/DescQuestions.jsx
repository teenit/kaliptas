import React from "react";
const DescQuestions =()=>{
    return(
        <div>DescQuestions</div>
    )
}
export default DescQuestions;