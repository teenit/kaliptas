import React from "react";
const DescFeedbacks =()=>{
    return(
        <div>DescFeedbacks</div>
    )
}
export default DescFeedbacks;