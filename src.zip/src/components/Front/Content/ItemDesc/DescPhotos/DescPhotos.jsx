import React from "react";
const DescPhotos =()=>{
    return(
        <div>DescPhotos</div>
    )
}
export default DescPhotos;