import React from "react";
import s from './FloatButton.module.css'
const FloatButton =()=>{
    return(
        <div className={s.float__button}></div>
    )
}
export default FloatButton;