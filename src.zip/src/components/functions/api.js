import axios from "axios";

export function serverAdress(arg){
    return "http://kaliptas/" + arg;
}

export function api(apiFunc, obj, url){
    obj.id = localStorage.getItem('id');
    obj.token = localStorage.getItem('token');
    if(obj?.email){

    }else{
        obj.email = localStorage.getItem('email');
    }
    
    axios({
        url: serverAdress(url),
        method: "POST",
        header: {'Content-Type': 'application/json;charset=utf-8'},
        data: JSON.stringify(obj),
        onUploadProgress: (event) => {
            console.log(event)
            document.getElementById('lineLoading').style.width = Math.round((event.loaded * 100) / event.total) + "%"
        } 
    })
    .then((data)=>{
        console.log(data);
        apiFunc(data.data)
        document.getElementById('lineLoading').style.width = 0;
    })
    .catch((error)=>{console.log(error.response.data)})
}