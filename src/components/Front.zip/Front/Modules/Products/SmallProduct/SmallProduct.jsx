import React from "react";
import s from './smallproduct.module.css'
const SmallProduct = ()=>{

    return(
        <div className={s.product}>

        </div>
    )
}
export default SmallProduct;