import React from "react";
import s from './FloatButton.module.css'
const FrontFloatButton =()=>{
    return(
        <div className={s.float__button}></div>
    )
}
export default FrontFloatButton;