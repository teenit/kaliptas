import React from "react";
import s from './FrontPage.module.css';
const FrontPage = ()=>{

    return(
        <div>
            FrontPage
        </div>
    )
}

export default FrontPage