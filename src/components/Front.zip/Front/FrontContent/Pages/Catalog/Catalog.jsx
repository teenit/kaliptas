import React from "react";

const Catalog = ()=>{
    return(
        <div>
            Catalog
        </div>
    )
}
export default Catalog;