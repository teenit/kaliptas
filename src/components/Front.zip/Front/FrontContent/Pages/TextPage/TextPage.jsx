import React from "react";

const TextPage = ()=>{
    return(
        <div>
            TextPage
        </div>
    )
}
export default TextPage;