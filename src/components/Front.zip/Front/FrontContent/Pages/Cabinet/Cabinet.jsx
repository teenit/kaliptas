import React from "react";

const Cabinet = ()=>{
    return(
        <div>
            Cabinet
        </div>
    )
}
export default Cabinet